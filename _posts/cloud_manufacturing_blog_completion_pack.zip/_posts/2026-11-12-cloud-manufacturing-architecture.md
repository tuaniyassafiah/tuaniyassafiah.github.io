---
layout: post
title: "Cloud Manufacturing Architecture and Its Layers"
date: 2026-11-10 02:00:00 +0800
categories: [cloud-manufacturing]
permalink: /cloud-manufacturing-architecture/
---

## 1. Introduction

Cloud Manufacturing uses digital platforms to connect manufacturing resources, service providers and users. To coordinate these activities, a cloud manufacturing system requires an architecture that organises its resources, data, services and user interactions.

A multi-layer architecture is commonly used to describe how information moves between physical manufacturing resources and the digital platform. The exact number and names of layers can differ between research models and commercial platforms. This article presents a general conceptual structure rather than one mandatory standard.

## 2. General Cloud Manufacturing Architecture

A simplified cloud manufacturing architecture can be understood through five functional layers.

**2.1 Physical Resource Layer**

This layer contains the manufacturing resources that perform physical activities. Examples include machines, robots, tools, production lines, inspection equipment and human expertise.

**2.2 Perception and Data Acquisition Layer**

This layer collects information from physical resources. Sensors, RFID readers, machine controllers and monitoring devices can capture information such as machine status, location, operating conditions and production output.

**2.3 Network and Communication Layer**

This layer transfers information between manufacturing resources, gateways and digital platforms. It may use wired or wireless networks and industrial communication technologies.

**2.4 Cloud Platform and Service Layer**

This layer provides data storage, computing, resource management and service functions. It can support resource registration, service discovery, scheduling, monitoring and coordination.

**2.5 Application and User Layer**

This layer provides interfaces for customers, engineers, managers and service providers. Users can search for services, submit requirements, view status information and manage manufacturing requests.

## 3. Information Flow Between Layers

The layers work together to connect physical manufacturing activities with digital services.

1. Machines and equipment perform manufacturing activities.
2. Sensors and controllers collect operational information.
3. Communication networks transfer the information to the platform.
4. The cloud platform stores and processes the information.
5. Service functions organise resources and match them with user requirements.
6. Users access the platform through applications and receive relevant information.

Information may also flow in the opposite direction when approved production instructions, service requests or configuration data are sent to manufacturing resources.

## 4. Important Platform Functions

**4.1 Resource Registration**

Providers register information about available machines, equipment, capabilities and capacity.

**4.2 Resource Discovery**

Users search for manufacturing resources or services that match their requirements.

**4.3 Service Composition**

A platform may combine several resources or services to fulfil a more complex manufacturing request.

**4.4 Scheduling and Coordination**

Scheduling functions help coordinate resource availability, task requirements and delivery expectations.

**4.5 Monitoring and Feedback**

The platform may collect status information and provide feedback about service progress and performance.

## 5. Technologies Supporting the Architecture

- **IoT and RFID:** Identify resources and collect operational data.
- **Cloud Computing:** Provides storage and computing infrastructure.
- **Edge Computing:** Supports local processing near machines and devices.
- **Data Analytics and AI:** Help analyse information and support planning.
- **Cybersecurity:** Protects devices, networks, platform services and data.
- **APIs and Interoperability Standards:** Help different software systems exchange information.

## 6. Design Considerations

A cloud manufacturing architecture should be designed around the requirements of its users and service providers.

Important considerations include data security, system availability, interoperability, scalability, resource description, quality assurance and clear access permissions. The architecture should also account for the performance and safety requirements of connected manufacturing equipment.

## 7. Conclusion

Cloud Manufacturing architecture organises the connection between physical manufacturing resources, data collection systems, communication networks, cloud services and user applications. A layered structure helps explain how these components interact and how manufacturing capabilities can be offered as digital services.

Although architecture models differ, an effective design should support reliable communication, secure information exchange, resource discovery and coordination between service users and providers.

## References

1. Gharibvand, V., Kolamroudi, M. K., Zeeshan, Q., & Çınar, Z. M. (2024). Cloud based manufacturing: A review of recent developments in architectures, technologies, infrastructures, platforms and associated challenges. *The International Journal of Advanced Manufacturing Technology, 131*, 93–123. https://doi.org/10.1007/s00170-024-12989-y
2. Chiappa, S., Videla, E., Viana-Céspedes, V., Piñeyro, P., & Rossit, D. A. (2023). Cloud manufacturing architectures: State-of-art, research challenges and platforms description. *Journal of Industrial Information Integration, 34*, 100472. https://doi.org/10.1016/j.jii.2023.100472
