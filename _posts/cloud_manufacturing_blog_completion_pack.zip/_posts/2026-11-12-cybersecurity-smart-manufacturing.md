---
layout: post
title: "Cybersecurity in IoT and Smart Manufacturing"
date: 2026-11-10 05:00:00 +0800
categories: [cloud-manufacturing, cybersecurity]
permalink: /cybersecurity-smart-manufacturing/
---

## 1. Introduction

Cybersecurity refers to the practices and technologies used to protect computer systems, networks, devices and information from unauthorised access, disruption or damage. It is especially important in smart manufacturing because industrial machines and production systems are increasingly connected to digital networks.

Manufacturing environments use information technology (IT) and operational technology (OT). IT systems manage information, while OT systems monitor or control physical equipment and industrial processes. A cybersecurity incident affecting OT may influence production, equipment availability, product quality and worker safety.

The National Institute of Standards and Technology (NIST) explains that OT security must consider the performance, reliability and safety requirements of systems that interact with the physical environment.

## 2. Common Cybersecurity Threats

**2.1 Malware and Ransomware**

Malware is malicious software designed to disrupt, damage or gain unauthorised access to systems. Ransomware may prevent access to files or systems until a payment is demanded.

**2.2 Phishing and Social Engineering**

Attackers may trick employees into revealing credentials or opening harmful links and attachments.

**2.3 Unauthorised Access**

Weak passwords, shared accounts or poorly managed permissions may allow unauthorised users to access industrial systems.

**2.4 Network Attacks**

Poorly protected networks may be exposed to attacks that interrupt communication or allow attackers to move between connected systems.

**2.5 Vulnerable Devices**

Older machines, unsupported software and poorly configured IoT devices may contain security weaknesses.

## 3. Potential Impacts on Manufacturing

Cybersecurity incidents can have consequences beyond the loss of digital information.

- **Production disruption:** Systems may become unavailable, interrupting manufacturing activities.
- **Equipment risks:** Unauthorised changes to control settings may affect equipment operation.
- **Product quality issues:** Manipulated or inaccurate process information may affect quality.
- **Data loss:** Designs, production records and business information may be exposed or destroyed.
- **Safety concerns:** Disruption to systems that monitor or control physical processes may create safety risks.
- **Financial losses:** Organisations may experience recovery costs, delays and reputational damage.

## 4. Cybersecurity Measures

**4.1 Asset Inventory**

Manufacturers should identify connected devices, machines, software, controllers and network connections. An accurate inventory helps organisations understand what needs protection.

**4.2 Access Control**

Access should be limited according to job responsibilities. Unique user accounts, strong authentication and timely removal of unnecessary access help reduce risk.

**4.3 Network Segmentation**

Separating networks into controlled zones can limit unnecessary communication between office IT systems and industrial OT systems.

**4.4 Secure Configuration and Updates**

Systems should use secure configurations. Security updates should be assessed and tested carefully before being applied to operational equipment.

**4.5 Backup and Recovery**

Important production data and system configurations should be backed up. Recovery procedures should be tested so that operations can be restored after an incident.

**4.6 Monitoring and Incident Response**

Organisations should monitor systems for unusual activity and prepare a response plan that identifies responsibilities, escalation steps and recovery actions.

**4.7 Employee Awareness**

Workers should be trained to recognise phishing, protect credentials, report suspicious activity and follow approved procedures.

## 5. Balancing Cybersecurity and Operational Requirements

Industrial systems often have strict requirements for availability, timing and safety. A security measure that is suitable for an office computer may not be appropriate for a production controller without careful assessment.

Manufacturers should evaluate security changes with engineering and operational teams. Testing should take place before changes are introduced into critical production environments. Safety and continuity of operations must remain central considerations.

## 6. Relationship with Cloud Manufacturing and IIoT

Cloud manufacturing and IIoT increase connectivity between machines, organisations and digital platforms. This connectivity can improve monitoring and collaboration, but it also creates additional systems and communication paths that need protection.

For example, a factory may transmit machine data to a cloud platform for analysis. The organisation should control who can access the platform, protect data during transmission and storage, monitor connections and plan for service interruptions.

## 7. Conclusion

Cybersecurity is essential for connected manufacturing because digital systems increasingly interact with physical equipment and production processes. Threats such as malware, phishing, unauthorised access and network attacks can affect production, information and safety.

Manufacturers should apply a risk-based approach that includes asset management, access control, network segmentation, backups, monitoring and employee training. Effective cybersecurity requires cooperation between IT, engineering, operations and management teams.

## References

1. Stouffer, K., Pease, M., Tang, C., et al. (2023). *Guide to Operational Technology (OT) Security* (NIST SP 800-82 Rev. 3). National Institute of Standards and Technology. https://doi.org/10.6028/NIST.SP.800-82r3
2. National Institute of Standards and Technology. (2024). *The NIST Cybersecurity Framework (CSF) 2.0*. https://doi.org/10.6028/NIST.CSWP.29
3. National Institute of Standards and Technology. (2022). *Protecting Information and System Integrity in Industrial Control System Environments: Cybersecurity for the Manufacturing Sector* (NIST SP 1800-10). https://www.nccoe.nist.gov/projects/building-blocks/manufacturing
