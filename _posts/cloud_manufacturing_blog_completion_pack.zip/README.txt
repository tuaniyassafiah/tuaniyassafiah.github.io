# Cloud Manufacturing Blog — Completion Pack

This package contains seven additional Jekyll blog posts (Articles 15–21).

## How to publish

1. Open your GitHub repository: `tuaniyassafiah.github.io`.
2. Open the `_posts` folder.
3. Upload all seven `.md` files from this package into `_posts`.
4. Commit the changes directly to the `main` branch.
5. GitHub Pages will build and publish the posts.

You can upload multiple files in one action using **Add file → Upload files**.

## Suggested commit message

`Add remaining cloud manufacturing articles`

## Included posts

15. Blockchain Technology in Manufacturing and Supply Chain Management
16. Cybersecurity in IoT and Smart Manufacturing
17. Introduction to Cloud Manufacturing
18. Cloud Manufacturing Architecture and Its Layers
19. Applications of Cloud Manufacturing in Modern Industry
20. Benefits and Challenges of Cloud Manufacturing
21. Future Trends of Cloud Manufacturing and Smart Factories

## Important notes

- Keep the filenames unchanged because Jekyll uses the date-prefixed `_posts` naming convention.
- The articles are written as general educational expansions using the references listed inside each post. They are not claimed to be detailed explanations from the Week 5 lecture slides.
- Check the rendered pages after deployment. The expected permalink for each post is specified in its front matter.
- This package does not overwrite your existing homepage, About Me, Learning Journal or Cloud Manufacturing pages.
